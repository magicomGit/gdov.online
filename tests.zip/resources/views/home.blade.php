
<x-app-layout>
    <div class="max-w-7xl mx-auto px-4">

        <x-home.lastNews :posts="$posts" />

        <div class="my-8"><img class="object-cover min-h-[60px]" src="img/orn-red.webp" alt=""></div>

        <x-home.afisha/>

    </div>

</x-app-layout>
