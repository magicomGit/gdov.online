<svg width="40" height="40" viewBox="0 0 15 15" version="1.1" id="museum" xmlns="http://www.w3.org/2000/svg">
    <path id="path7509" d="M7.5,0L1,3.5V4h13V3.5L7.5,0z M2,5v5l-1,1.6V13h13v-1.4L13,10V5H2z M4,6h1v5.5H4V6z M7,6h1v5.5H7V6z M10,6h1&#xA;&#x9;v5.5h-1V6z"/>
  </svg>
