
<x-app-layout>


        <x-home.lastNews :posts="$posts" />

        <div class="my-8"><img class="object-cover min-h-[60px]" src="img/orn-red.webp" alt=""></div>

        <x-home.afisha/>



</x-app-layout>
