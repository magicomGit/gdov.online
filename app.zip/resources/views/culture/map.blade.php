<style>
    .more {
        color: white;
        background-color: #3C8C73;
        padding: 4px;
        border: solid 1px lightgray;
    }

    .museumOff svg {
        fill: #ed4543;
    }

    .museumOff {
        color: #ed4543;
        border-color: #ed4543;
        background-color: white;
    }

    @media (min-width: 640px) {
        .museumOff:hover {
            color: white;
            border-color: white;
            background-color: #ed4543;
        }

        .museumOff:hover svg {
            fill: white;
        }
    }

    .museumOn svg {
        fill: white;
    }

    .museumOn {
        color: white;
        border-color: white;
        background-color: #ed4543;
    }

    /* ---------------------- */
    .monumentOff svg {
        fill: #97a100;
    }

    .monumentOff {
        color: #97a100;
        border-color: #97a100;
        background-color: white;
    }

    @media (min-width: 640px) {
        .monumentOff:hover {
            color: white;
            border-color: white;
            background-color: #97a100;
        }

        .monumentOff:hover svg {
            fill: white;
        }
    }

    .monumentOn svg {
        fill: white;
    }

    .monumentOn {
        color: white;
        border-color: white;
        background-color: #97a100;
    }

    /* ---------------------- */
    .archOff svg {
        fill: #793d0e;
    }

    .archOff {
        color: #793d0e;
        border-color: #793d0e;
        background-color: white;
    }

    @media (min-width: 640px) {
        .archOff:hover {
            color: white;
            border-color: white;
            background-color: #793d0e;
        }

        .archOff:hover svg {
            fill: white;
        }
    }

    .archOn svg {
        fill: white;
    }

    .archOn {
        color: white;
        border-color: white;
        background-color: #793d0e;
    }

    /* ---------------------- */
    .religionOff svg {
        fill: #1bad03;
    }

    .religionOff {
        color: #1bad03;
        border-color: #1bad03;
        background-color: white;
    }

    @media (min-width: 640px) {
        .religionOff:hover {
            color: white;
            border-color: white;
            background-color: #1bad03;
        }

        .religionOff:hover svg {
            fill: white;
        }
    }

    .religionOn svg {
        fill: white;
    }

    .religionOn {
        color: white;
        border-color: white;
        background-color: #1bad03
    }

    /* ---------------------- */
    .hotelOff svg {
        fill: #0e4779;
    }

    .hotelOff {
        color: #0e4779;
        border-color: #0e4779;
        background-color: white;
    }

    @media (min-width: 640px) {
        .hotelOff:hover {
            color: white;
            border-color: white;
            background-color: #0e4779;
        }

        .hotelOff:hover svg {
            fill: white;
        }
    }



    .hotelOn svg {
        fill: white;
    }

    .hotelOn {
        color: white;
        border-color: white;
        background-color: #0e4779
    }
</style>

<x-app-layout>

    <H2 class="sm:text-4xl text-2xl font-bold border-b border-gray-300 py-2 mb-4">Интерактивная карта Гдовского
        района</H2>

    <div class="flex flex-wrap justify-center gap-2 py-2">

        <div id="museum" onclick="layerSelect('museum')"
            class="flex items-center gap-3 border-2  px-3 h-[52px] rounded-lg shadow-md cursor-pointer
                  transition duration-300 ease-in-out museumOff">
            <div class="w-12 ">
                <x-svg.museum :color="'#ed4543'" />
            </div>
            <div class="font-bold">Музеи</div>
        </div>

        <div id="monument" onclick="layerSelect('monument')"
            class="flex items-center gap-3 border-2  px-3 h-[52px] rounded-lg shadow-md cursor-pointer
                  transition duration-300 ease-in-out monumentOff">
            <div class="h-10 ">
                <x-svg.monument />
            </div>
            <div class=" font-bold">Памятники</div>
        </div>

        <div id="arch" onclick="layerSelect('arch')"
            class="flex items-center gap-3 border-2  px-3 h-[52px] rounded-lg shadow-md cursor-pointer
                transition duration-300 ease-in-out archOff">
            <div class="h-10 ">
                <x-svg.arch :color="'#793d0e'" />
            </div>
            <div class="font-bold">Архитектура</div>
        </div>

        <div id="religion" onclick="layerSelect('religion')"
            class="flex items-center gap-3 border-2  px-3 h-[52px] rounded-lg shadow-md cursor-pointer
                transition duration-300 ease-in-out religionOff">
            <div class="h-12 ">
                <x-svg.religion :color="'#1bad03'" />
            </div>
            <div class="font-bold">Церкви</div>
        </div>

        <div id="hotel" onclick="layerSelect('hotel')"
            class="flex items-center gap-3 border-2  px-3 h-[52px] rounded-lg shadow-md cursor-pointer
                transition duration-300 ease-in-out hotelOff">
            <div class="h-12 ">
                <x-svg.hotel :color="'#0e4779'" />
            </div>
            <div class="font-bold">Базы отдыха</div>
        </div>
    </div>




    <div id="map" style=" height: 500px"></div>
    <div class="py-6"><img class="object-cover min-h-[60px]" src="{{ config('app.url') }}/img/orn-red.webp"
            alt=""></div>


</x-app-layout>

<script src="https://api-maps.yandex.ru/2.1/?apikey=4adcaf3b-9daf-4fa8-94da-121704fbfc5e&lang=ru_RU"
    type="text/javascript"></script>



<script type="text/javascript">



    var appUrl = '{{ config('app.url') }}';

    var colorred = "#ed4543"
    var myMap;
    var placemarkCollections = {};
    var clusterer = {};
    var layerCollection = {
        'museum': false,
        'monument': false,
        'arch': false,
        'religion': false,
        'hotel': false
    };


    var markers = [{
            layer: 'museum',
            coord: [58.28996536, 27.62414847],
            title: 'Музей Ледового побоища',
            img: appUrl + '/img/culture/samolvarf.webp',
            description: 'Гдовский район, д.Самолва',
            link: appUrl + '#',
            iconColorPreset: 'islands#redIcon',
        },
        {
            layer: 'museum',
            coord: [58.29005606, 27.62023656],
            title: 'Музей рыбацкого края',
            img: appUrl + '/img/culture/musambar.webp',
            description: 'Гдовский район, д.Самолва',
            link: appUrl + '#',
            iconColorPreset: 'islands#redIcon',
        },
        {
            layer: 'monument',
            coord: [58.29807890, 27.62006890],
            title: 'Александр Невский с дружиной',
            img: appUrl + '/img/culture/icefight.webp',
            description: 'Гдовский район, д.Самолва',
            link: appUrl + '#',
            iconColorPreset: 'islands#oliveStretchyIcon',
        },
        {
            layer: 'arch',
            coord: [58.74084140, 27.81943020],
            title: 'Гдовская крепость',
            img: appUrl + '/img/culture/300-fort.webp',
            description: 'г.Гдов',
            link: appUrl + '#',
            iconColorPreset: 'islands#brownStretchyIcon',
        },
        {
            layer: 'religion',
            coord: [58.74012748, 27.82037434],
            title: 'Собор в честь Державной иконы</br> Божией Матери',
            img: appUrl + '/img/culture/300-hram.webp',
            description: 'г.Гдов',
            link: appUrl + '#',
            iconColorPreset: 'islands#darkGreenStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.43504985, 28.25809144],
            title: 'Эко Парк Большая Рыба',
            img: appUrl + '/img/culture/300-bigfish.webp',
            description: 'Гдовский район, Полновская волость. База отдыха',
            link: 'https://vk.com/bolshayariba',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'museum',
            coord: [58.74531862, 27.82056792],
            title: 'Гдовский музей истории края',
            img: appUrl + '/img/culture/300-museum.webp',
            description: 'г.Гдов',
            link: 'http://gdovmus.ru',
            iconColorPreset: 'islands#redStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.45906381, 27.79537661],
            title: 'Остров спасения. Дом отдыха.',
            img: appUrl + '/img/culture/300-islandsave.webp',
            description: 'Гдовский район, Раскопель.',
            link: 'https://travel.yandex.ru/hotels/pskov-oblast/ostrov-spaseniia/',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.42891325, 27.90755732],
            title: 'Точка притяжения. Дом отдыха.',
            img: appUrl + '/img/culture/300-pointgrav.webp',
            description: 'Гдовский район, д. Ореховцы.',
            link: 'https://travel.yandex.ru/hotels/pskov-oblast/ostrov-spaseniia/',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.54163167, 27.85012828],
            title: 'Гостевой дом Чудской.',
            img: appUrl + '/img/culture/300-chudskoi.webp',
            description: 'Гдовский район, д.Спицино.',
            link: 'http://chudskoi.ru',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.62486839, 27.80080202],
            title: 'Хутор Утешение, отдых на ферме.',
            img: appUrl + '/img/culture/300-hutor.webp',
            description: 'Гдовский район, д.Спицино.',
            link: 'https://yandex.ru/profile/1702594909',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.47842124, 27.88089553],
            title: 'Усадьба "Друг" </br>Отдых и Рыбалкана Чудском',
            img: appUrl + '/img/culture/300-frend.webp',
            description: 'Гдовский район, д.Залахтовье.',
            link: 'https://vk.com/club86894330',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.42487057, 27.79144737],
            title: 'База отдыха Тишина',
            img: appUrl + '/img/culture/300-silence.webp',
            description: 'Гдовский район, Спицинская волость.',
            link: 'https://yandex.ru/profile/166673202058',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.78781564, 27.85336997],
            title: 'База отдыха Чистые Пруды',
            img: appUrl + '/img/culture/300-cleanpond.webp',
            description: 'Гдовский район, д.Верхоляне-2.',
            link: 'https://yandex.ru/maps/org/baza_otdykha_chistyye_prudy/201701578828/?ll=27.866704%2C58.785775&z=14',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.47969686, 27.88196842],
            title: 'Тридевятое царство',
            img: appUrl + '/img/culture/300-999.webp',
            description: 'Гдовский район, д.Залахтовье.',
            link: 'https://baza999.ru',
            iconColorPreset: 'islands#nightStretchyIcon',
        },
        {
            layer: 'hotel',
            coord: [58.75528066, 27.78430079],
            title: 'Гостевой дом Устье',
            img: appUrl + '/img/culture/300-ust.webp',
            description: 'Гдовский район, п.Устье.',
            link: 'https://yandex.ru/maps/org/gostevoy_dom_ustye/204062193564/?ll=27.784280%2C58.755270&z=16',
            iconColorPreset: 'islands#nightStretchyIcon',
        }
        //olive brown darkGreen night
    ]

    function layerSelect(name) {
        layerCollection[name] = !layerCollection[name];
        let layer = document.querySelector('#' + name);



        if (layerCollection[name]) {
            clusterer.add(placemarkCollections[name])
            myMap.geoObjects.add(clusterer)
            layer.classList.remove(name + 'Off')
            layer.classList.add(name + 'On')
        } else {
            clusterer.remove(placemarkCollections[name])
            myMap.geoObjects.removeAll()
            myMap.geoObjects.add(clusterer)
            layer.classList.remove(name + 'On')
            layer.classList.add(name + 'Off')
        }
    }






    ymaps.ready(init);

    function init() {
        document.querySelector('#menu').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        // Создаем карту
        myMap = new ymaps.Map("map", {
            center: [58.52461183, 27.84345160],
            zoom: 9,
            controls: [
                'zoomControl'
            ],
            zoomMargin: [20]
        });

        clusterer = new ymaps.Clusterer({
            clusterIconLayout: 'default#pieChart', // Макет метки кластера pieChart.
            clusterIconPieChartRadius: 25, // Радиус диаграммы в пикселях.
            clusterIconPieChartCoreRadius: 10, // Радиус центральной части макета.
            clusterIconPieChartStrokeWidth: 3, // Ширина линий-разделителей секторов и внешней обводки диаграммы.
            hasBalloon: false
        }); // Определяет наличие поля balloon.



        var museumCollection = [];
        var monumentCollection = [];
        var archCollection = [];
        var religionCollection = [];
        var hotelCollection = [];

        var iconColorPreset = '';

        markers.map((marker) => {
            plaseMarker = new ymaps.Placemark(marker.coord, {
                balloonContentHeader: marker.title,
                balloonContentBody: '<img src="' + marker.img + '" height="200" width="300"> <br/> ' +
                    marker.description + '<br/>',
                balloonContentFooter: '<a class="more" href="' + marker.link + '">Подробнее</a>',
                //iconContent: marker.title,
                // Зададим содержимое всплывающей подсказки.
                hintContent: marker.title
            }, {
                preset: marker.iconColorPreset,
            });

            switch (marker.layer) {
                case 'museum':
                    museumCollection.push(plaseMarker);
                    break;
                case 'monument':
                    monumentCollection.push(plaseMarker);
                    break;
                case 'arch':
                    archCollection.push(plaseMarker);
                    break;
                case 'religion':
                    religionCollection.push(plaseMarker);
                    break;
                case 'hotel':
                    hotelCollection.push(plaseMarker);
                    break;

                default:
                    break;
            }

        })



        //myMap.geoObjects.add(clusterer)


        placemarkCollections['museum'] = museumCollection;
        placemarkCollections['monument'] = monumentCollection;
        placemarkCollections['arch'] = archCollection;
        placemarkCollections['religion'] = religionCollection;
        placemarkCollections['hotel'] = hotelCollection;



    }
</script>
