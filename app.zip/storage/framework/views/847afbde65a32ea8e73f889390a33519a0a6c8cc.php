<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto p-4">

        <div class="py-2  mb-2">
            <a class=" bg-[#3C8C73] p-2 px-4 text-white" href=<?php echo e(route('posts.create')); ?>>Добавить новость</a>
        </div>

        <div class="pb-4  ">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex justify-between border border-gray-300 -mb-[1px] gap-4 p-2">
                    <div class="flex gap-4 items-center">
                        <div class="text-md "><?php echo e($post->created_at->format('d.m.Y')); ?></div>

                            <?php echo e($post->title); ?>


                    </div>

                    <div class="flex gap-4">
                        <a href=<?php echo e(route('posts.edit', $post->id)); ?>>
                            <img class="w-6 h-6" src="<?php echo e(config('app.url', 'http://localhost')); ?>/img/svg/edit.svg">
                        </a>

                        <a href=<?php echo e(route('post.show', $post->id)); ?>>
                            <img class="w-6 h-6" src="<?php echo e(config('app.url', 'http://localhost')); ?>/img/svg/delete.svg">
                        </a>

                    </div>



                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($posts); ?>

        </div>


    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\OSPanel\domains\laravel\resources\views/profile/news.blade.php ENDPATH**/ ?>