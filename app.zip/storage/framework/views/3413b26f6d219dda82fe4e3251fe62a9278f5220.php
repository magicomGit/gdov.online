
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto px-4">
        <H2 class="text-4xl font-bold border-b border-gray-300 py-2 mb-4">Новости Гдовского района</H2>

        <div class="pb-4  flex flex-col gap-4">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col sm:flex-row  gap-3">
                    <div class="sm:w-1/2 ">
                        <a href=<?php echo e(route('post.show', $post->id)); ?>>
                            <div class="w-full overflow-hidden max-w-[600px]">
                                <img class=" hover:opacity-90 transition duration-200 ease-in-out"
                                    src="img/<?php echo e($post->pictures[0]->path); ?>/600-<?php echo e($post->pictures[0]->picture); ?> " />
                            </div>
                        </a>
                    </div>

                    <div class="sm:w-1/2 flex flex-col sm:justify-between border-b sm:border-none ">
                        <a href=<?php echo e(route('post.show', $post->id)); ?>

                            class="block  text-3xl font-semibold hover:text-[#3C8C73] text-[#2f6d59] transition-colors duration-200 ease-in-out">
                            <?php echo e($post->title); ?>

                        </a>
                        <div class="pt-2  text-sm sm:order-2"><?php echo e($post->created_at->format('d.m.Y')); ?></div>
                        <div class=""><?php echo $post->preview; ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($posts); ?>

        </div>

        
    </div>


    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script>
    document.querySelector('#menu').scrollIntoView({block: 'start'});
</script>
<?php /**PATH D:\OSPanel\domains\laravel\resources\views/posts/posts.blade.php ENDPATH**/ ?>